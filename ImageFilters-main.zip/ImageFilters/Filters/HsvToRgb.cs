﻿namespace ImageFilters.Filters;



internal class HsvToRgbFilter : AbstractFunctionalFilter
{
    public HsvToRgbFilter(Bitmap originalImage): base(originalImage) { }

    public override Bitmap Apply()
    {
        return Apply(HsvToRgb);
    }

    private (byte, byte, byte) HsvToRgb(byte h, byte s, byte v)
    {
        float normalized_hue = h / 255.0f;
        float normalized_sat = s / 255.0f;
        float normalized_val = v / 255.0f;

        float hue_angle = normalized_hue * 360;
        float c = normalized_sat * normalized_val;
        float x = c * (1 - Math.Abs((hue_angle / 60) % 2 - 1));
        float m = normalized_val - c;

        float red, green, blue;

        if (hue_angle < 60)
        {
            red = c;
            green = x;
            blue = 0;
        }
        else if (hue_angle < 120)
        {
            red = x;
            green = c;
            blue = 0;
        }
        else if (hue_angle < 180)
        {
            red = 0;
            green = c;
            blue = x;
        }
        else if (hue_angle < 240)
        {
            red = 0;
            green = x;
            blue = c;
        }
        else if (hue_angle < 300)
        {
            red = x;
            green = 0;
            blue = c;
        }
        else
        {
            red = c;
            green = 0;
            blue = x;
        }

        return ((byte)((red + m) * 255), (byte)((green + m) * 255), (byte)((blue + m) * 255));
    }
}
