﻿namespace ImageFilters.Filters;

internal class RgbToHueFilter : AbstractFunctionalFilter
{
    public RgbToHueFilter(Bitmap image): base(image) { }
    public override Bitmap Apply()
    {
        return Apply(RgbToHsvConversion);
    }

    private (byte, byte, byte) RgbToHsvConversion(byte r, byte g, byte b)
    {
        float normalized_r = r / 255.0f;
        float normalized_g = g / 255.0f;
        float normalized_b = b / 255.0f;

        float value = Math.Max(normalized_b, Math.Max(normalized_g, normalized_r));
        float hue_temp, hue;
        if (value == normalized_r)
        {
            hue_temp = ((normalized_g - normalized_b) / value) % 6;
        }
        else if (value == normalized_g)
        {
            hue_temp = ((normalized_b - normalized_r) / value) + 2;
        }
        else
        {
            hue_temp = ((normalized_r - normalized_g) / value) + 4;
        }

        hue = hue_temp * 60;
        if(hue < 0)
        {
            hue += 360;
        }
        if(hue > 360)
        {
            hue %= 360;
        }
        float saturation;
        if(value == 0)
        {
            saturation = 0;
        }
        else
        {
            saturation = (value - Math.Min(normalized_r, Math.Min(normalized_g, normalized_b))) / value;
        }
        return ((byte)(hue / 360 * 255), (byte)(saturation * 255), (byte)(value * 255));
    }
}
