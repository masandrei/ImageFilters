﻿using ImageFilters.Filters;

unsafe class UniformColorQuantization : AbstractFunctionalFilter
{
    private readonly byte[] _quantizationMapRed = new byte[256];
    private readonly byte[] _quantizationMapGreen = new byte[256];
    private readonly byte[] _quantizationMapBlue = new byte[256];

    public UniformColorQuantization(Bitmap image, int[] intervals) : base(image)
    {
        if (intervals.Any(x => x < 2) || intervals.Any(x => x > 256))
            throw new ArgumentException("Intervals must be between 2 and 256.");
        _quantizationMapRed = InitializeQuantizationMap(intervals[0]);
        _quantizationMapGreen = InitializeQuantizationMap(intervals[1]);
        _quantizationMapBlue = InitializeQuantizationMap(intervals[2]);
    }

    private byte[] InitializeQuantizationMap(int intervals)
    {
        var quant = new byte[256];
        int step = 255 / (intervals - 1);

        for (int i = 0; i < 256; i++)
        {
            int closest = (int)Math.Round((double)i / step) * step;
            quant[i] = (byte)Math.Clamp(closest, 0, 255);
        }
        return quant;
    }

    public override unsafe Bitmap Apply()
    {
        return Apply((r, g, b) => (_quantizationMapRed[r], _quantizationMapGreen[g], _quantizationMapBlue[b]));
    }
}
